﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;
using $safeprojectname$.Pages;

namespace $safeprojectname$
{
    [Binding]
    public sealed class Setup
    {
        private static string websiteUrl = ConfigurationSettings.AppSettings["WebSiteUrl"];

        [BeforeFeature]
        public static void BeforeFeature()
        {
            IWebDriver driver = new ChromeDriver();
            FeatureContext.Current.Set(driver);
            driver.Navigate().GoToUrl(websiteUrl);
        }

        [AfterFeature]
        public static void AfterFeature()
        {
            // Clear up the webdriver
            var webDriver = FeatureContext.Current.Get<IWebDriver>();
            webDriver.Quit();
            webDriver.Dispose();
        }

        [BeforeScenario]
        public void BeforeScenario()
        {
            // At the begining of the scenario, we are on the homepage
            var webDriver = FeatureContext.Current.Get<IWebDriver>();
            var homePage = new HomePage(webDriver);
            ScenarioContext.Current.Set<HomePage>(homePage);
        }

        [AfterScenario]
        public void AfterScenario()
        {
            //TODO: implement logic that has to run after executing each scenario
        }
    }
}
